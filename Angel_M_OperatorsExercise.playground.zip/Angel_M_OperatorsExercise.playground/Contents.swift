import UIKit

var str = "Hello, playground"

var number1 = 0
var number2 = 5
var number3 = 10
var number4 = 15
var number5 = 20
var number6 = 25

2 + 2
2 - 2
2 * 2
2/2

print (number1 * number5)
print (number4 + number6)
print (number4 / number4)
print (number3 - number6)
